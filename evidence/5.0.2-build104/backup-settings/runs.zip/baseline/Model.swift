import Foundation
import Observation
@MainActor @Observable final class OathCloudBackupModel {
    var record: CloudBackupRecord?
    var preparing = false
    var loaded = false
    var failure: String?
    private var work: Task<Void, Never>?
    private var operationID = UUID()

    func observe(walletID: String) async {
        cancelPreparation()
        record = nil; loaded = false; failure = nil
        do {
            let db = try await OathDataEnvironment.shared.database()
            try Task.checkCancellation()
            try await db.reconcileRemovedCloudBackups()
            let initial = try await db.cloudBackup(walletID: walletID)
            try Task.checkCancellation()
            record = initial
            loaded = true
            if record?.enabled == true { retry(walletID: walletID) }
            for try await record in db.observeCloudBackup(walletID: walletID) {
                try Task.checkCancellation()
                let newlyUploaded = record?.state == "uploaded" && self.record?.state != "uploaded"
                self.record = record
                if newlyUploaded { failure = nil }
            }
        } catch is CancellationError { }
        catch { OathDiagnostics.record(error); if !Task.isCancelled { failure = "failed" } }
    }
    func create(walletID: String, password: String, vault: OathWalletVault) {
        guard !preparing else { return }
        cancelPreparation()
        let operation = operationID
        preparing = true; failure = nil
        work = Task {
            defer { finish(operation) }
            do { try await OathCloudBackupService.shared.create(walletID: walletID, password: password, vault: vault) }
            catch is CancellationError { }
            catch { OathDiagnostics.record(error); if !Task.isCancelled { failure = OathCloudBackupService.failureCode(error) } }
        }
    }
    func disable(walletID: String) {
        cancelPreparation()
        let operation = operationID
        work = Task {
            defer { finish(operation) }
            do {
                try await OathCloudBackupService.shared.disable(walletID: walletID)
                try Task.checkCancellation()
                failure = nil
            } catch { OathDiagnostics.record(error); if !Task.isCancelled { failure = "failed" } }
        }
    }
    func retry(walletID: String) {
        cancelPreparation()
        let operation = operationID
        let record = record
        work = Task {
            defer { finish(operation) }
            do {
                try await OathCloudBackupService.shared.checkAvailability(for: record)
                try await OathCloudBackupService.shared.resume()
                try Task.checkCancellation()
                failure = nil
            } catch { OathDiagnostics.record(error); if !Task.isCancelled { failure = OathCloudBackupService.failureCode(error) } }
        }
    }
    func cancelPreparation() {
        work?.cancel(); work = nil; preparing = false
        operationID = UUID()
    }
    private func finish(_ operation: UUID) {
        // A cancelled job for a previously viewed wallet must not clear the
        // progress or task of the wallet currently open in this same sheet.
        guard operationID == operation else { return }
        preparing = false; work = nil
    }
}

extension OathCloudBackupModel { var reviewTask: Task<Void, Never>? { work } }
