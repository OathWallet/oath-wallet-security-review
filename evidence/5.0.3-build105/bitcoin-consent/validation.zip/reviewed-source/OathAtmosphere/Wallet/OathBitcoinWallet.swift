import Foundation
import WalletCore
import OathBitcoin
import OathCloudBackup
import OathDatabase

extension OathImportedPrivateKey {
    func extendedKey(for network: UTXONetwork) throws -> String? {
        let stored: String? = switch network {
        case .bitcoin: bitcoinExtendedKey
        case .dogecoin: dogecoinExtendedKey
        case .litecoin: litecoinExtendedKey
        case .bitcoincash: bitcoinCashExtendedKey
        }
        guard let stored else { return nil }
        return try network.restoredExtendedPrivateKey(stored, storedScalar: bytes)
    }

    func bitcoinDescriptor() throws -> BitcoinWalletDescriptor {
        guard isValidStructure, networks.count == 1,
              let network = UTXONetwork(rawValue: networks[0].id) else { throw OathWalletError.invalidPrivateKey }
        if let extended = try extendedKey(for: network) {
            return try network.extended(extended)
        }
        return try network.singleKey(bytes: bytes, compressed: compressed != false)
    }
}

extension OathWalletEngine {
    static func signBitcoin(_ plan: BitcoinSendPlan, secret: OathWalletSecret, accounts: [AccountRecord]) throws -> BitcoinSignedSend {
        if let material = secret.electrum {
            guard secret.hasValidMaterial, plan.chain == .bitcoin, plan.coins.allSatisfy({ coin in
                accounts.contains { $0.id == coin.accountID && $0.walletID == secret.id.uuidString && $0.networkID == "bitcoin" && $0.accountIndex == 0 }
            }) else { throw BitcoinSendError.invalidInput }
            return try ElectrumBitcoin.sign(plan, material: material)
        }
        if let multisig = secret.bitcoinMultisig {
            guard plan.chain == multisig.utxoNetwork, plan.coins.allSatisfy({ coin in
                accounts.contains { $0.id == coin.accountID && $0.walletID == secret.id.uuidString && $0.networkID == multisig.chainID && $0.accountIndex == 0 }
            }) else { throw BitcoinSendError.invalidInput }
            return try BitcoinMultisig.sign(plan, required: multisig.required, keys: multisig.signingKeys(), network: multisig.utxoNetwork)
        }
        var seed: Data?
        defer { if seed != nil { seed!.resetBytes(in: 0..<seed!.count) } }
        if let aezeed = secret.aezeed {
            guard plan.chain == .bitcoin, secret.hasValidMaterial else { throw BitcoinSendError.invalidInput }
            seed = aezeed.entropy
        } else if secret.privateKey == nil {
            let passphrase = try secret.bip39Passphrase
            guard OathMnemonicValidator.bundled?.verifiedPhrase(secret.mnemonic) != nil,
                  let wallet = HDWallet(mnemonic: secret.mnemonic, passphrase: passphrase, check: false) else { throw OathWalletError.derivationFailed }
            seed = wallet.seed
        }
        let source: (String) throws -> BitcoinPrivateKeySource = { accountID in
            guard let account = accounts.first(where: { $0.id == accountID }), account.walletID == secret.id.uuidString,
                  account.networkID == plan.chain.rawValue, account.accountIndex >= 0, account.accountIndex < 0x8000_0000 else { throw BitcoinSendError.invalidInput }
            if let material = secret.privateKey {
                guard material.isValidStructure, material.networks.map(\.rawValue) == [plan.chain.rawValue] else { throw BitcoinSendError.invalidInput }
                if let extended = try material.extendedKey(for: plan.chain) {
                    return .extended(extended)
                }
                return .single(material.bytes, compressed: material.compressed != false)
            }
            guard let seed else { throw BitcoinSendError.signing }
            return secret.aezeed != nil ? .aezeed(seed, account: UInt32(account.accountIndex)) : .seed(seed, account: UInt32(account.accountIndex))
        }
        if plan.chain == .bitcoincash { return try BitcoinCashSendSigner.sign(plan, source: source) }
        return try BitcoinSendSigner.sign(plan, source: source)
    }
    static func bitcoinDescriptor(for secret: OathWalletSecret, account: UInt32, network: UTXONetwork = .bitcoin) throws -> BitcoinWalletDescriptor {
        if let material = secret.electrum {
            guard network == .bitcoin, account == 0, secret.hasValidMaterial else { throw OathWalletError.invalidPhrase }
            return try ElectrumBitcoin.wallet(material)
        }
        if let aezeed = secret.aezeed {
            guard network == .bitcoin, secret.hasValidMaterial else { throw OathWalletError.invalidPhrase }
            return try BitcoinKeys.aezeedWallet(entropy: aezeed.entropy, account: account)
        }
        if let multisig = secret.bitcoinMultisig {
            guard network == multisig.utxoNetwork, account == 0 else { throw OathWalletError.invalidPrivateKey }
            return try multisig.descriptor()
        }
        if let key = secret.privateKey {
            let descriptor = try key.bitcoinDescriptor()
            guard descriptor.network == network else { throw OathWalletError.invalidPrivateKey }
            return descriptor
        }
        let passphrase = try secret.bip39Passphrase
        guard OathMnemonicValidator.bundled?.verifiedPhrase(secret.mnemonic) != nil,
              let wallet = HDWallet(mnemonic: secret.mnemonic, passphrase: passphrase, check: false) else { throw OathWalletError.derivationFailed }
        var seed = wallet.seed
        defer { seed.resetBytes(in: 0..<seed.count) }
        return try network.wallet(seed: seed, account: account)
    }
}


enum OathBitcoinConnectSignature {
    case transaction(BitcoinConnectSigned)
    case message(BitcoinConnectMessageSignature)
}
extension OathWalletEngine {
    static func signWalletConnectBitcoin(_ request: BitcoinConnectRequest, plan: BitcoinConnectPlan?,
        address: BitcoinDerivedAddress?, secret: OathWalletSecret, account: AccountRecord) throws -> OathBitcoinConnectSignature {
        guard secret.hasValidMaterial, account.walletID == secret.id.uuidString, account.networkID == "bitcoin",
              account.accountIndex >= 0, account.accountIndex < 0x8000_0000, secret.bitcoinMultisig == nil else { throw BitcoinConnectError.wrongAccount }
        var seed: Data?
        defer { if seed != nil { seed!.resetBytes(in:0..<seed!.count) } }
        let source: BitcoinPrivateKeySource
        if let material = secret.electrum { source = .electrum(material) }
        else if let key = secret.privateKey {
            guard key.isValidStructure, key.networks.map(\.rawValue) == ["bitcoin"] else { throw BitcoinConnectError.wrongAccount }
            if let extended = try key.extendedKey(for: .bitcoin) {
                source = .extended(extended)
            } else { source = .single(key.bytes,compressed:key.compressed != false) }
        } else if let material = secret.aezeed {
            seed = material.entropy; source = .aezeed(seed!,account:UInt32(account.accountIndex))
        } else {
            guard OathMnemonicValidator.bundled?.verifiedPhrase(secret.mnemonic) != nil,
                  let wallet = HDWallet(mnemonic:secret.mnemonic,passphrase:try secret.bip39Passphrase,check:false) else { throw OathWalletError.derivationFailed }
            seed = wallet.seed; source = .seed(seed!,account:UInt32(account.accountIndex))
        }
        if let plan {
            guard plan.request == request else { throw BitcoinConnectError.changed }
            return .transaction(try BitcoinConnectSigning.sign(plan,source:source))
        }
        guard let address else { throw BitcoinConnectError.wrongAccount }
        return .message(try BitcoinConnectSigning.message(request,address:address,source:source))
    }
}
