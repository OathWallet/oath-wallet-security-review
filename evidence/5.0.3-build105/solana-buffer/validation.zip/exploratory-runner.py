import subprocess,pathlib,json,hashlib,time,concurrent.futures,re,sys
source=pathlib.Path('<SOURCE>')
phase=sys.argv[1];build=pathlib.Path(sys.argv[2]);out=pathlib.Path(sys.argv[3]);out.mkdir(exist_ok=False)
bundles=list(build.glob('*/debug/*.xctest'));assert len(bundles)==1
bundle=bundles[0];executable=bundle/'Contents/MacOS/OathAnkrPackageTests'
fixture=source/'Packages/OathAnkr/Tests/OathAnkrTests/WalletConnectSolanaBufferTests.swift'
listed=subprocess.run(['swift','test','--package-path',str(source/'Packages/OathAnkr'),'--build-system','native','--scratch-path',str(build),'list','--skip-build','--disable-swift-testing'],capture_output=True,text=True,check=True)
(out/'discovery-stderr.log').write_text(listed.stderr)
selectors=[n for n in listed.stdout.splitlines() if n.startswith('OathAnkrTests.WalletConnectSolana') and (phase!='before' or 'BufferTests/' in n)]
assert selectors and all(re.fullmatch(r'[\w.]+/\w+',n) for n in selectors)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name):
 t=time.monotonic();r=subprocess.run(['/usr/bin/sandbox-exec','-p','(version 1) (allow default) (deny network*)','xcrun','xctest','-XCTest',name,str(bundle)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120)
 log=r.stdout.replace(str(source),'<SOURCE>');fn=hashlib.sha256(name.encode()).hexdigest()[:16]+'.log';(out/fn).write_text(log)
 passes=len(re.findall(r"^Test Case '.+' passed ",log,re.M));started=len(re.findall(r"^Test Case '.+' started\.$",log,re.M));skips=len(re.findall(r"^Test Case '.+' skipped ",log,re.M))
 status='passed' if r.returncode==0 and started==1 and passes==1 and skips==0 else 'failed'
 return dict(selector=name,status=status,exit_code=r.returncode,duration_seconds=round(time.monotonic()-t,3),log=fn,log_sha256=digest(out/fn))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:r=list(pool.map(run,selectors))
metadata=dict(phase=phase,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),fixture_sha256=digest(fixture),executable_sha256=digest(executable),network='denied during each test',results=r)
metadata['sources']=[dict(path=str(p.relative_to(source)),sha256=digest(p)) for p in sorted((source/'Packages/OathAnkr/Sources').rglob('WalletConnectSolana*.swift'))]
(out/'results.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps({s:sum(n['status']==s for n in r) for s in ['passed','failed']}))
