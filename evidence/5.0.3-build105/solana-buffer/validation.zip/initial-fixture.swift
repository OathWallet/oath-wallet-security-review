import XCTest
@testable import OathAnkr

/// Public, synthetic SDK vectors; no network access or funded accounts.
final class WalletConnectSolanaBufferTests: XCTestCase {
    private struct Fixture: Decodable { let vectors: [Vector] }
    private struct Vector: Decodable { let account: String, unsigned: String, signed: String }
    private func vectors() throws -> [Vector] {
        let url = try XCTUnwrap(Bundle.module.url(forResource: "solana", withExtension: "json", subdirectory: "Fixtures/WalletConnect"))
        return try JSONDecoder().decode(Fixture.self, from: Data(contentsOf: url)).vectors
    }
    private func slice(_ bytes: Data, offset: Int) -> Data {
        (Data(repeating: 0xA5, count: offset) + bytes).dropFirst(offset)
    }

    func testOrdinaryWireBuffersRetainTheirExactMessageAndSignatures() throws {
        for vector in try vectors() {
            let unsigned = try XCTUnwrap(Data(base64Encoded: vector.unsigned))
            let signed = try XCTUnwrap(Data(base64Encoded: vector.signed))
            let tx = try WalletConnectSolanaTransaction(bytes: unsigned, account: vector.account)
            let parsed = try WalletConnectSolanaTransaction(bytes: signed, account: vector.account)
            XCTAssertEqual(tx.message, parsed.message)
            try tx.verifySigned(signed, requireAll: true)
        }
    }

    func testSlicedUnsignedWireRetainsExactMessageAndNormalizedStorage() throws {
        for vector in try vectors() {
            let bytes = try XCTUnwrap(Data(base64Encoded: vector.unsigned))
            let ordinary = try WalletConnectSolanaTransaction(bytes: bytes, account: vector.account)
            for offset in [1, 128, 1024] {
                let sliced = slice(bytes, offset: offset)
                XCTAssertEqual(sliced.startIndex, offset)
                let parsed = try WalletConnectSolanaTransaction(bytes: sliced, account: vector.account)
                XCTAssertEqual(parsed.message, ordinary.message)
                XCTAssertEqual(parsed.bytes, bytes)
                XCTAssertEqual(parsed.bytes.startIndex, 0)
                XCTAssertEqual(parsed, ordinary)
            }
        }
    }

    func testSlicedSignedWireVerifiesAndTamperingStillFails() throws {
        for vector in try vectors() {
            let unsigned = try XCTUnwrap(Data(base64Encoded: vector.unsigned))
            let signed = try XCTUnwrap(Data(base64Encoded: vector.signed))
            let ordinary = try WalletConnectSolanaTransaction(bytes: unsigned, account: vector.account)
            for offset in [1, 128, 1024] {
                let sliced = slice(signed, offset: offset)
                XCTAssertEqual(sliced.startIndex, offset)
                let parsed = try WalletConnectSolanaTransaction(bytes: sliced, account: vector.account)
                XCTAssertEqual(parsed.message, ordinary.message)
                try ordinary.verifySigned(sliced, requireAll: true)
                var corrupt = signed; corrupt[2] ^= 1
                XCTAssertThrowsError(try ordinary.verifySigned(slice(corrupt, offset: offset), requireAll: true))
            }
        }
    }
}
