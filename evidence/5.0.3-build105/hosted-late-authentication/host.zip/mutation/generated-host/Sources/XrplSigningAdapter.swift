import Foundation
import OathAnkr
import OathDatabase
extension OathWalletEngine { static func signXrpl(_ plan:XrplSendPlan, secret:OathWalletSecret, account:AccountRecord) throws -> XrplSignedSend { throw XrplSendError.signing } }