import Foundation
import OathAnkr
import OathDatabase
import OathDiagnostics

struct OathNearQuote: Sendable, Equatable {
    let walletID: String, accountID: String, assetID: String
    let plan: NearSendPlan
}

