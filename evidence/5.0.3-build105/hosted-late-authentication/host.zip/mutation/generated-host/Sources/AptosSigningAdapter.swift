import Foundation
import OathAnkr
import OathDatabase
extension OathWalletEngine { static func signAptos(_ plan:AptosSendPlan, secret:OathWalletSecret, account:AccountRecord) throws -> AptosSignedSend { throw AptosSendError.signing }; static func aptosPublicKey(secret:OathWalletSecret,account:AccountRecord) throws -> Data { throw AptosSendError.signing } }