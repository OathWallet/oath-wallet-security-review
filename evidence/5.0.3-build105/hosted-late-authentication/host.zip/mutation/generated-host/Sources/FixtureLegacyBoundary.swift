import Foundation
import CryptoKit
import Security
import OathDatabase
import OathCloudBackup
import OathDiagnostics
import OathBitcoin

/// Retained origin and naming metadata inside authenticated ciphertext only.
/// Current import rules determine the destination accounts and address types.
struct OathLegacyWalletMetadata: Codable, Sendable {
    let wallet: LegacyWallet
    let accounts: [LegacyAccount]
}

protocol OathLegacySecretReading: Sendable {
    func read(reference: String) throws -> Data
}

struct OathLegacyKeychain: OathLegacySecretReading {
    func read(reference: String) throws -> Data {
        guard !reference.isEmpty, reference.utf8.count < 512 else { throw LegacyUpgradeError.keyUnavailable }
        var query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "com.codex.prototype.evmwallet.secrets",
            kSecAttrAccount as String: reference,
            kSecAttrSynchronizable as String: false,
            kSecMatchLimit as String: kSecMatchLimitOne, kSecReturnData as String: true
        ]
        #if !targetEnvironment(simulator)
        query[kSecAttrAccessGroup as String] = "C5T44SZNQX.com.aperture.wallet"
        #endif
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess, let data = item as? Data else {
            OathDiagnostics.record(DiagnosticFailure("legacy_keychain_read"), component: "legacy_upgrade", operation: "keychain_read",
                                   context: ["stage": "read", "reason": "keychain_status_\(status)"])
            throw LegacyUpgradeError.keyUnavailable
        }
        return data
    }
}

struct OathLegacyPasscodeCredential: Decodable {
    let algorithm: String
    let iterations: UInt32
    let salt: Data
    let verifier: Data

    func validate() throws {
        guard algorithm == "pbkdf2-hmac-sha256", [210_000, 310_000].contains(iterations),
              salt.count == 32, verifier.count == 32 else { throw LegacyUpgradeError.invalidCredential }
    }

    static func read(reference: String, secrets: any OathLegacySecretReading) throws -> Self {
        func decoded(_ reference: String) throws -> Self {
            var data = try secrets.read(reference: reference)
            defer { data.resetBytes(in: 0..<data.count) }
            let credential = try JSONDecoder().decode(Self.self, from: data)
            try credential.validate()
            return credential
        }
        do { return try decoded(reference) }
        catch {
            // Old releases maintain this recovery alias. Only a missing/corrupt
            // credential permits fallback; an incorrect PIN never does.
            OathDiagnostics.record(DiagnosticFailure("legacy_verifier_primary_unavailable"), component: "legacy_upgrade", operation: "verifier_read")
            return try decoded(reference + ".passcode-verifier-backup")
        }
    }

    func matches(_ digits: [UInt8]) throws -> Bool {
        try validate()
        let candidate = try OathPasscodeRecord.make(digits: digits, salt: Array(salt), iterations: iterations).verifier
        return zip(candidate, verifier).reduce(UInt8(0)) { $0 | ($1.0 ^ $1.1) } == 0
    }
}

struct OathLegacyUnlockAttempts: Codable {
    var failures: Int
    var blockedUntil: Date?
    mutating func recordAttempt(now: Date) {
        failures = min(failures + 1, 20)
        if failures >= 5 {
            let delays: [TimeInterval] = [5, 30, 300, 1_800, 3_600, 21_600]
            blockedUntil = now.addingTimeInterval(delays[min(failures - 5, delays.count - 1)])
        }
    }
}

enum OathLegacyUpgrade {
        static let sourceURL = URL(fileURLWithPath: "/nonexistent-oath-host-fixture/legacy.sqlite")
        static func rootID(for source: LegacyWalletSnapshot) throws -> UUID {
            guard let id = source.wallets.first.flatMap({ UUID(uuidString: $0.id) }) else { throw LegacyUpgradeError.invalidSource }
            return id
        }
        static func prepare(_ source: LegacyWalletSnapshot, secrets: any OathLegacySecretReading) throws
            -> (OathVaultContents, LegacyUpgradeBatch) { throw LegacyUpgradeError.unsupportedWallet }
    }
    