import Foundation
import OathAnkr
import OathDatabase
import OathDiagnostics

struct OathTonQuote: Sendable, Equatable {
    let walletID: String, accountID: String, assetID: String
    let plan: TonSendPlan
}

