
import Foundation
import CommonCrypto
struct Bech32 { static func decode(string: String) -> Data? { nil } }
struct HDWallet {
    let seed: Data
    enum Coin { case ethereum, ton, tron, xrp, stellar, aptos, sui, near, thorchain }
    struct Key { let data: Data }
    // This host harness does not emulate WalletCore TRON HD derivation. Raw-key
    // material is tested here; phrase derivation needs its own independent vectors.
    func getKey(coin: Coin, derivationPath: String) -> Key? { nil }
    init?(mnemonic: String, passphrase: String, check: Bool) {
        let password = Data(mnemonic.decomposedStringWithCompatibilityMapping.utf8)
        let salt = Data(("mnemonic" + passphrase.decomposedStringWithCompatibilityMapping).utf8)
        var output = Data(count: 64)
        let result = password.withUnsafeBytes { p in salt.withUnsafeBytes { s in output.withUnsafeMutableBytes { out in
            CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), p.baseAddress!.assumingMemoryBound(to: Int8.self), p.count,
                s.baseAddress!.assumingMemoryBound(to: UInt8.self), s.count, CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA512),
                2048, out.baseAddress!.assumingMemoryBound(to: UInt8.self), out.count)
        } } }
        guard result == kCCSuccess else { return nil }
        seed = output
    }
}
