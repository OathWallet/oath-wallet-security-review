import Foundation
import OathAnkr
import OathDatabase
import OathDiagnostics

struct OathTronQuote: Sendable, Equatable {
    let walletID: String, accountID: String, assetID: String
    let plan: TronSendPlan
}

