import Foundation
import OathAnkr
import OathBitcoin
import OathDatabase
extension OathWalletEngine { static func signWalletConnectBitcoin(_ request: BitcoinConnectRequest, plan: BitcoinConnectPlan?,
        address: BitcoinDerivedAddress?, secret: OathWalletSecret, account: AccountRecord) throws -> OathBitcoinConnectSignature { preconditionFailure("Unselected chain signer is outside this host harness") } }
enum OathBitcoinConnectSignature {
    case transaction(BitcoinConnectSigned)
    case message(BitcoinConnectMessageSignature)
}
extension OathWalletEngine { static func signWalletConnectTon(_ request: WalletConnectTonRequest, plan: WalletConnectTonPlan?, secret: OathWalletSecret, account: AccountRecord) throws -> OathTonWalletConnectSignature { preconditionFailure("Unselected chain signer is outside this host harness") } }
extension OathWalletEngine { static func signWalletConnectTonProof(_ request: WalletConnectTonProofRequest, timestamp: UInt64, secret: OathWalletSecret, account: AccountRecord) throws -> Data { preconditionFailure("Unselected chain signer is outside this host harness") } }
enum OathTonWalletConnectSignature: Sendable {
    case transaction(TonSignedSend)
    case data(TonJSON)
}
extension OathWalletEngine { static func signWalletConnectTron(_ request: WalletConnectTronRequest, review: WalletConnectTronReview?, secret: OathWalletSecret, account: AccountRecord) throws -> TronJSON { preconditionFailure("Unselected chain signer is outside this host harness") } }
extension OathWalletEngine { static func signWalletConnectPolkadot(_ request: WalletConnectPolkadotRequest, review: PolkadotConnectReview?, secret: OathWalletSecret, account: AccountRecord) throws -> TronJSON { preconditionFailure("Unselected chain signer is outside this host harness") } }
extension OathWalletEngine { static func suiPublicKey(secret:OathWalletSecret, account:AccountRecord) throws -> Data { preconditionFailure("Unselected chain signer is outside this host harness") } }
extension OathWalletEngine { static func signWalletConnectSui(_ request:WalletConnectSuiRequest, review:WalletConnectSuiReview?, secret:OathWalletSecret, account:AccountRecord) throws -> WalletConnectSuiSignature { preconditionFailure("Unselected chain signer is outside this host harness") } }
extension OathWalletEngine { static func signWalletConnectNear(_ request:WalletConnectNearRequest,review:WalletConnectNearReview,secret:OathWalletSecret,account:AccountRecord) throws -> NearJSON { preconditionFailure("Unselected chain signer is outside this host harness") } }
extension OathWalletEngine { static func signWalletConnectStellar(_ request: WalletConnectStellarRequest, review: WalletConnectStellarReview, secret: OathWalletSecret, account: AccountRecord) throws -> WalletConnectStellarSigned { preconditionFailure("Unselected chain signer is outside this host harness") } }
extension OathWalletEngine { @concurrent static func signWalletConnectXrpl(_ request: WalletConnectXrplRequest, review: WalletConnectXrplReview, secret: OathWalletSecret, account: AccountRecord) async throws -> WalletConnectXrplSigned { preconditionFailure("Unselected chain signer is outside this host harness") } }