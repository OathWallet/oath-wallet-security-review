import Foundation
import OathAnkr
import OathDatabase
extension OathWalletEngine { static func signEVM(_ plan:EVMSendPlan, secret:OathWalletSecret, account:AccountRecord) throws -> EVMSignedSend { throw EVMSendError.signing } }
