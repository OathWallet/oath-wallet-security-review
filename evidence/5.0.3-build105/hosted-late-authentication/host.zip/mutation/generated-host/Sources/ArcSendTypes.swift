import Foundation
import OathAnkr
import OathDatabase
import OathDiagnostics

struct OathArcQuote: Sendable, Equatable {
    let walletID: String, accountID: String, assetID: String
    let plan: ArcSendPlan
}

