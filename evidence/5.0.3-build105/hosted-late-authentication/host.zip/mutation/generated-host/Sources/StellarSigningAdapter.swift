import Foundation
import OathAnkr
import OathDatabase
extension OathWalletEngine { static func signStellar(_ plan:StellarSendPlan, secret:OathWalletSecret, account:AccountRecord) throws -> StellarSignedSend { throw StellarSendError.signing } }