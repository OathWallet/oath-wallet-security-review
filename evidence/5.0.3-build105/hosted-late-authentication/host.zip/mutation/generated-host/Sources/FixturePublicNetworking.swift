
import OathAnkr
import Foundation
import OathMarketData
// This harness never starts catalog searches or token additions. Keep their
// cancellation boundary inert alongside the other public-network fixtures;
// TokenLookupValidation exercises the production token selection model.
@MainActor final class OathTokenSelectionModel {
    func cancel() { }
}
enum OathTokenAddress {
    static func checksum(_ address: String) -> String {
        preconditionFailure("Catalog artwork belongs to TokenLookupValidation, not wallet selection tests")
    }
}
actor OathTokenService {
    static let shared = OathTokenService()
    func resolveForAdding(_ token: OathTokenDefinition, owner: String?) async throws -> OathTokenDefinition {
        preconditionFailure("Token metadata requests belong to TokenLookupValidation, not wallet selection tests")
    }
}
// Background send recovery is outside this authentication harness. Like sync
// below, it is replaced at the network boundary, never in vault authorization.
actor OathStellarSendService {
    static let shared = OathStellarSendService()
    func recover(vault: OathWalletVault) async { }
}
actor OathTronSendService {
    static let shared = OathTronSendService()
    func recover(vault: OathWalletVault) async { }
}
actor OathNearSendService {
    static let shared = OathNearSendService()
    func recover(vault: OathWalletVault) async { }
}
actor OathXrplSendService {
    static let shared = OathXrplSendService()
    func recover(vault: OathWalletVault) async { }
}
actor OathSuiSendService {
    static let shared = OathSuiSendService()
    func recover(vault: OathWalletVault) async { }
}
actor OathBitcoinSendService {
    static let shared = OathBitcoinSendService()
    static let cash = OathBitcoinSendService()
    static let litecoin = OathBitcoinSendService()
    static let dogecoin = OathBitcoinSendService()
    func recover(vault: OathWalletVault) async { }
}
@MainActor final class OathSendStatusTracking {
    static let shared = OathSendStatusTracking()
    func beginReset() async {}
    func endReset() {}
}
actor OathPostSendBalanceRefresh {
    static let shared = OathPostSendBalanceRefresh()
    func resume(vault: OathWalletVault) async { }
    func pause() async { }
    func reset() async { }
}
actor OathBitcoinSync {
    static let shared = OathBitcoinSync()
    private var refreshFailure: (any Error)?
    func setRefreshFailure(_ error: (any Error)?) { refreshFailure = error }
    func refresh(accountID: String, vault: OathWalletVault) async throws {
        try Task.checkCancellation()
        if let refreshFailure { throw refreshFailure }
    }
    func cancel() async { }
}
actor OathAnkrSync {
    static let shared = OathAnkrSync()
    private var refreshFailure: (any Error)?
    private(set) var completedSolanaRefreshes = 0
    func setRefreshFailure(_ error: (any Error)?) { refreshFailure = error }
    func refresh(walletID: String) async throws {
        try Task.checkCancellation()
        if let refreshFailure { throw refreshFailure }
    }
    func refreshBalances(walletID: String) async throws { try Task.checkCancellation() }
    func refreshCronos(walletID: String) async throws { try Task.checkCancellation() }
    func refreshSolana(accountID: String) async throws {
        try Task.checkCancellation(); completedSolanaRefreshes += 1
    }
    func refreshTron(accountID: String) async throws { try Task.checkCancellation() }
    func refreshTon(accountID: String) async throws { try Task.checkCancellation() }
    func refreshAptos(accountID: String) async throws { try Task.checkCancellation() }
    func refreshThorchain(accountID: String) async throws { try Task.checkCancellation() }
    func refreshSui(accountID: String) async throws { try Task.checkCancellation() }
    func refreshNear(accountID: String) async throws { try Task.checkCancellation() }
    func refreshPolkadot(accountID: String) async throws { try Task.checkCancellation() }
    func refreshXrpl(accountID: String) async throws { try Task.checkCancellation() }
    func refreshStellar(accountID: String) async throws { try Task.checkCancellation() }
    func refreshHyperEVM(accountID: String) async throws { try Task.checkCancellation() }
    func refreshIndexedEVM(accountID: String, chain: IndexedEVMChain) async throws { try Task.checkCancellation() }
    func refreshRobinhood(accountID: String) async throws { try Task.checkCancellation() }
    func refreshArc(accountID: String) async throws { try Task.checkCancellation() }
    func cancel() async { }
}
actor OathMarketEnvironment {
    static let shared = OathMarketEnvironment()
    func service() async throws -> FixtureMarketService { FixtureMarketService() }
}
struct FixtureMarketService: Sendable {
    func quote(for asset: MarketAsset) async throws { try Task.checkCancellation() }
}
