import Foundation
import OathAnkr
import OathDatabase
import OathDiagnostics

struct OathSolanaQuote: Sendable, Equatable {
    let walletID: String, accountID: String, assetID: String
    let plan: SolanaSendPlan
}

