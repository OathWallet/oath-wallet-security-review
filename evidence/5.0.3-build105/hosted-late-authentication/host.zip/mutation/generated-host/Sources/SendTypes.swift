import OathDiagnostics
import Foundation
import OathBitcoin
import OathDatabase

struct OathBitcoinQuote: Sendable, Equatable {
    let walletID: String
    let accountID: String
    let plan: BitcoinSendPlan
}
struct OathBitcoinSubmission: Sendable {
    let txid: String
    let accepted: Bool
}

