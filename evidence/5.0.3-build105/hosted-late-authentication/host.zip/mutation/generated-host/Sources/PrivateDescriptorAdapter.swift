import Foundation
import OathBitcoin
import OathCloudBackup
import OathDatabase

extension OathImportedPrivateKey {
    func extendedKey(for network: UTXONetwork) throws -> String? {
        let stored: String? = switch network {
        case .bitcoin: bitcoinExtendedKey
        case .dogecoin: dogecoinExtendedKey
        case .litecoin: litecoinExtendedKey
        case .bitcoincash: bitcoinCashExtendedKey
        }
        guard let stored else { return nil }
        return try network.restoredExtendedPrivateKey(stored, storedScalar: bytes)
    }

    func bitcoinDescriptor() throws -> BitcoinWalletDescriptor {
        guard isValidStructure, networks.count == 1,
              let network = UTXONetwork(rawValue: networks[0].id) else { throw OathWalletError.invalidPrivateKey }
        if let extended = try extendedKey(for: network) {
            return try network.extended(extended)
        }
        return try network.singleKey(bytes: bytes, compressed: compressed != false)
    }
}

