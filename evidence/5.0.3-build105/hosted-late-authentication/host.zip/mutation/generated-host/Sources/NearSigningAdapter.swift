import Foundation
import OathAnkr
import OathDatabase
extension OathWalletEngine { static func signNear(_ plan:NearSendPlan, secret:OathWalletSecret, account:AccountRecord) throws -> NearSignedSend { throw NearSendError.signing }; static func nearPublicKey(secret:OathWalletSecret,account:AccountRecord) throws -> Data { throw NearSendError.signing } }