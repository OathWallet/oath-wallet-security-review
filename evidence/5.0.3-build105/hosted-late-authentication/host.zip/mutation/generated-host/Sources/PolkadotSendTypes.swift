import Foundation
import OathAnkr
import OathDatabase
import OathDiagnostics

struct OathPolkadotQuote: Sendable, Equatable {
    let walletID: String, accountID: String, assetID: String
    let plan: PolkadotSendPlan
}

