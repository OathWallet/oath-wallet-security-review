import OathBitcoin
import OathAnkr
import OathDatabase
import CryptoKit
import OathAezeed
import OathBitcoin
import Foundation
import OathCloudBackup

struct OathWalletAddress: Identifiable, Equatable, Sendable {
    let chain: OathImportChain
    let address: String
    let path: String
    var accountIndex: Int = 0
    var accountID: String? = nil
    var assetID: String? = nil
    var storedNetworkName: String? = nil
    var storedTicker: String? = nil
    var storedLogo: String? = nil
    var networkName: String { storedNetworkName ?? chain.name }
    var ticker: String { storedTicker ?? chain.ticker }
    var logo: String { storedLogo ?? chain.logoAsset }
    // Persisted accounts remain distinct when a wallet owns multiple accounts
    // on one chain. Pure derivation fixtures use the chain as their initial ID.
    var id: String { accountID ?? chain.id }
}

struct OathWalletProfile: Identifiable, Equatable, Sendable {
    let id: UUID
    let addresses: [OathWalletAddress]
    let createdAt: Date
    let backedUp: Bool
}

/// Account 0 / external address 0, with Phantom's default for Solana.
/// EVM networks intentionally share Ethereum's key, including Telos EVM.

enum OathWalletEngine {
    static func fixtureSolanaAddress(_ secret: OathWalletSecret, path: String) -> String {
        // Intentionally synthetic public metadata; never represents a real key.
        let alphabet = Array("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz")
        return "FixtureSo1" + SHA256.hash(data: Data((secret.id.uuidString + path).utf8)).map { String(alphabet[Int($0) % 58]) }.joined()
    }
    static func solanaReceiveAddresses(for secret: OathWalletSecret, account: AccountRecord) throws -> [SolanaReceiveAddress] {
        if secret.privateKey != nil || secret.solanaMultisig != nil { return [.init(path: account.derivationPath, address: account.address)] }
        let index = SolanaDerivation.accountIndex(in: account.derivationPath) ?? account.accountIndex
        var paths = try SolanaDerivation.allCases.map { try $0.path(accountIndex: index) }
        if !paths.contains(account.derivationPath) { paths.append(account.derivationPath) }
        return paths.map { .init(path: $0, address: fixtureSolanaAddress(secret, path: $0)) }
    }
    static func create(id: UUID = UUID()) throws -> OathWalletSecret {
        .init(id: id, mnemonic: "synthetic generated fixture " + id.uuidString.lowercased(),
              language: "english", createdAt: .now, backedUp: false)
    }
    static func imported(_ phrase: OathValidatedMnemonic, id: UUID = UUID()) throws -> OathWalletSecret {
        .init(id: id, mnemonic: phrase.phrase, language: phrase.language,
              createdAt: .now, backedUp: true, imported: true)
    }
    static func imported(_ material: OathImportedPrivateKey, id: UUID = UUID()) throws -> OathWalletSecret {
        guard material.isValidStructure else { throw OathWalletError.invalidPrivateKey }
        return .init(id: id, mnemonic: "", language: "", createdAt: .now, backedUp: true,
                     imported: true, privateKey: material)
    }
    static func profile(for secret: OathWalletSecret, chains: Set<OathImportChain>? = nil) throws -> OathWalletProfile {
        DerivationGate.shared.waitIfArmed()
        if let multisig = secret.evmMultisig { return try multisigProfile(for: secret, material: multisig) }
        if let multisig = secret.tonMultisig { return try multisigProfile(for: secret, material: multisig) }
        if let multisig = secret.thorchainMultisig { return try multisigProfile(for: secret, material: multisig) }
        if let multisig = secret.nearMultisig { return try multisigProfile(for: secret, material: multisig) }
        if let multisig = secret.suiMultisig { return try multisigProfile(for: secret, material: multisig) }
        if let multisig = secret.aptosMultisig { return try multisigProfile(for: secret, material: multisig) }
        if let multisig = secret.stellarMultisig { return try multisigProfile(for: secret, material: multisig) }
        if let multisig = secret.xrplMultisig { return try multisigProfile(for: secret, material: multisig) }
        if let multisig = secret.solanaMultisig { return try multisigProfile(for: secret, material: multisig) }
        if let multisig = secret.tronMultisig { return try multisigProfile(for: secret, material: multisig) }
        if let multisig = secret.bitcoinMultisig { return try multisigProfile(for: secret, material: multisig) }
        let accounts = secret.restoration?.accounts ?? (secret.privateKey?.networks ?? OathImportChain.allCases).map {
            BackupWallet.Account(network: $0.id, derivationPath: secret.privateKey == nil ? $0.walletPath : "imported", index: 0)
        }
        return .init(id: secret.id, addresses: accounts.filter { chains == nil || chains!.contains(OathImportChain(rawValue:$0.network)!) }.map {
            .init(chain: OathImportChain(rawValue: $0.network)!, address: OathImportChain(rawValue: $0.network)!.isEVM && secret.privateKey != nil ? (try! ArcSendCrypto.address(privateKey: secret.privateKey!.bytes)) : $0.network == "solana" ? fixtureSolanaAddress(secret, path: $0.derivationPath) : "synthetic-address-" + secret.id.uuidString + $0.network + ($0.index == 0 ? "" : ":" + String($0.index)),
                  path: $0.derivationPath, accountIndex: $0.index)
        }, createdAt: secret.createdAt, backedUp: secret.backedUp)
    }
    static func privateKey(for secret: OathWalletSecret, account: OathPrivateKeyAccount) throws -> OathPrivateKeyExport {
        DerivationGate.shared.waitIfArmed()
        if let origin = account.utxo, let network = UTXONetwork(rawValue: account.chain.id) {
            let source: BitcoinPrivateKeySource
            if let key = secret.privateKey {
                if let extended = try key.extendedKey(for: network) { source = .extended(extended) }
                else { source = .single(key.bytes, compressed: key.compressed != false) }
            } else { source = .seed(Data(0..<32), account: origin.accountIndex) }
            return .init(value: try network.privateKeyWIF(source: source, address: origin.address), format: "WIF")
        }
        guard account.address == (account.chain == .solana ? fixtureSolanaAddress(secret, path: account.path) : "synthetic-address-" + secret.id.uuidString + account.chain.id) else {
            throw OathWalletError.derivationFailed
        }
        return .init(value: "synthetic-export-" + secret.id.uuidString + account.chain.id + account.path, format: "Synthetic fixture")
    }
}
extension OathImportChain {
    var walletPath: String {
        if isEVM { return "m/44'/60'/0'/0/0" }
        switch self {
        case .aptos: return "m/44'/637'/0'/0'/0'"
        case .bitcoin: return "m/84'/0'/0'/0/0"
        case .bitcoincash: return "m/44'/145'/0'/0/0"
        case .dogecoin: return "m/44'/3'/0'/0/0"
        case .litecoin: return "m/84'/2'/0'/0/0"
        case .thorchain: return "m/44'/931'/0'/0/0"
        case .near: return "m/44'/397'/0'"
        case .solana: return "m/44'/501'/0'/0'"
        case .polkadot: return "m/44'/354'/0'/0'/0'"
        case .stellar: return "m/44'/148'/0'"
        case .sui: return "m/44'/784'/0'/0'/0'"
        case .ton: return "m/44'/607'/0'"
        case .tron: return "m/44'/195'/0'/0/0"
        case .xrpl: return "m/44'/144'/0'/0/0"
        default: preconditionFailure("Every non-EVM chain must have an explicit path")
        }
    }

    var ticker: String {
        switch self {
        case .cronos: "CRO"
        case .aptos: "APT"
        case .bitcoin: "BTC"
        case .bitcoincash: "BCH"
        case .dogecoin: "DOGE"
        case .litecoin: "LTC"
        case .thorchain: "RUNE"
        case .near: "NEAR"
        case .solana: "SOL"
        case .polkadot: "DOT"
        case .stellar: "XLM"
        case .sui: "SUI"
        case .ton: "GRAM"
        case .tron: "TRX"
        case .xrpl: "XRP"
        case .bnb: "BNB"
        case .fantom: "FTM"
        case .flare: "FLR"
        case .somnia: "SOMI"
        case .story: "IP"
        case .avalanche: "AVAX"
        case .polygon: "POL"
        case .gnosis: "xDAI"
        case .telos: "TLOS"
        case .xlayer: "OKB"
        case .arc: "USDC"
        case .chiliz: "CHZ"
        case .filecoin: "FIL"
        case .iotex: "IOTX"
        case .zerog: "0G"
        case .sei: "SEI"
        case .celo: "CELO"
        case .monad: "MON"
        case .hyperevm: "HYPE"
        default: "ETH"
        }
    }
}

extension OathWalletEngine {
    static func signBitcoin(_ plan: BitcoinSendPlan, secret: OathWalletSecret, accounts: [AccountRecord]) throws -> BitcoinSignedSend {
        // Signing has separate deterministic package tests; this harness must
        // fail closed if an authentication check unexpectedly attempts a send.
        throw BitcoinSendError.signing
    }
    static func bitcoinDescriptor(for secret: OathWalletSecret, account: UInt32, network: UTXONetwork = .bitcoin) throws -> BitcoinWalletDescriptor {
        if let material = secret.electrum {
            guard network == .bitcoin, account == 0, secret.hasValidMaterial else { throw OathWalletError.invalidPhrase }
            return try ElectrumBitcoin.wallet(material)
        }
        if let aezeed = secret.aezeed {
            guard network == .bitcoin, secret.hasValidMaterial else { throw OathWalletError.invalidPhrase }
            return try BitcoinKeys.aezeedWallet(entropy: aezeed.entropy, account: account)
        }
        if let multisig = secret.bitcoinMultisig { return try multisig.descriptor() }
        if let key = secret.privateKey { return try key.bitcoinDescriptor() }
        return try network.wallet(seed: Data(0..<32), account: account)
    }
}
