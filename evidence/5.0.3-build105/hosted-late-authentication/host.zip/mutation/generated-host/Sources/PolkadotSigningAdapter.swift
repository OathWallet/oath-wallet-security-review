import Foundation
import OathAnkr
import OathDatabase
extension OathWalletEngine { static func signPolkadot(_ plan:PolkadotSendPlan, secret:OathWalletSecret, account:AccountRecord) throws -> PolkadotSignedSend { throw PolkadotSendError.signing } }
