import Foundation
import OathAnkr
import OathDatabase
extension OathWalletEngine { static func signSui(_ plan:SuiSendPlan, secret:OathWalletSecret, account:AccountRecord) throws -> SuiSignedSend { throw SuiSendError.signing } }