import Foundation
import OathAnkr
import OathDatabase
import OathDiagnostics

struct OathStellarQuote: Sendable, Equatable {
    let walletID: String, accountID: String, assetID: String
    let plan: StellarSendPlan
}

