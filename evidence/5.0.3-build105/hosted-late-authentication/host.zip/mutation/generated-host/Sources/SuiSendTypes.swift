import Foundation
import OathAnkr
import OathDatabase
import OathDiagnostics

struct OathSuiQuote: Sendable, Equatable {
    let walletID: String, accountID: String, assetID: String
    let plan: SuiSendPlan
}

