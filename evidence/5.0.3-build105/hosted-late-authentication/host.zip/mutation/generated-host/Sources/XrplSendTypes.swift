import Foundation
import OathAnkr
import OathDatabase
import OathDiagnostics

struct OathXrplQuote: Sendable, Equatable {
    let walletID: String, accountID: String, assetID: String
    let plan: XrplSendPlan
}

