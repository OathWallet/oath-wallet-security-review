import Foundation
import OathAnkr
import OathDatabase
import OathDiagnostics

struct OathThorchainQuote: Sendable, Equatable {
    let walletID: String, accountID: String, assetID: String
    let plan: ThorchainSendPlan
}

