import Foundation
import OathAnkr
import OathDatabase
extension OathWalletEngine { static func signTon(_ plan:TonSendPlan, secret:OathWalletSecret, account:AccountRecord) throws -> TonSignedSend { throw TonSendError.signing }; static func tonPublicKey(secret:OathWalletSecret,account:AccountRecord) throws -> Data { throw TonSendError.signing } }