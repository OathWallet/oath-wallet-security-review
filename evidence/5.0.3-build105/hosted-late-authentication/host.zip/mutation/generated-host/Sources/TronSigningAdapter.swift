import Foundation
import OathAnkr
import OathDatabase
extension OathWalletEngine { static func signTron(_ plan:TronSendPlan, secret:OathWalletSecret, account:AccountRecord) throws -> TronSignedSend { throw TronSendError.signing } }