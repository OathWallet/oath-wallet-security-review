import Foundation
import OathAnkr
import OathDatabase
import OathDiagnostics

struct OathEVMQuote: Sendable, Equatable {
    let walletID: String, accountID: String, assetID: String
    let plan: EVMSendPlan
}

