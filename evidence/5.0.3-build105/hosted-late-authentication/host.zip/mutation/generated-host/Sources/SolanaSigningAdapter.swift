import Foundation
import OathAnkr
import OathDatabase
extension OathWalletEngine { static func signWalletConnectSolana(_ request:WalletConnectSolanaRequest,secret:OathWalletSecret,account:AccountRecord) throws -> WalletConnectSolanaSigned { throw SolanaSendError.signing }; static func signSolana(_ plan:SolanaSendPlan, secret:OathWalletSecret, account:AccountRecord) throws -> SolanaSignedSend { throw SolanaSendError.signing }; static func solanaPublicKey(secret:OathWalletSecret,account:AccountRecord) throws -> Data { throw SolanaSendError.signing } }