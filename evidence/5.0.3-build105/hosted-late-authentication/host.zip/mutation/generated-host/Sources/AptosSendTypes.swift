import Foundation
import OathAnkr
import OathDatabase
import OathDiagnostics

struct OathAptosQuote: Sendable, Equatable {
    let walletID: String, accountID: String, assetID: String
    let plan: AptosSendPlan
}

