import Foundation
import OathAnkr
import OathDatabase
extension OathWalletEngine { static func signThorchain(_ plan:ThorchainSendPlan, secret:OathWalletSecret, account:AccountRecord) throws -> ThorchainSignedSend { throw ThorchainSendError.signing }; static func thorchainPublicKey(secret:OathWalletSecret,account:AccountRecord) throws -> Data { throw ThorchainSendError.signing }; static func signThorchainWalletConnect(_ request:ThorchainWalletConnectRequest,secret:OathWalletSecret,account:AccountRecord) throws -> SolanaJSON { throw ThorchainSendError.signing } }