import Foundation
import OathAnkr
import OathDatabase
extension OathWalletEngine { static func signArc(_ plan:ArcSendPlan, secret:OathWalletSecret, account:AccountRecord) throws -> ArcSignedSend { throw ArcSendError.signing } }