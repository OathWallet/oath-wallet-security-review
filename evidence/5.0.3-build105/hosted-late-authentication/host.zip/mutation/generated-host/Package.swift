// swift-tools-version: 6.1
import PackageDescription
let package = Package(
    name: "WalletValidation", platforms: [.macOS("15.5")],
    dependencies: [
        .package(path: "<SOURCE>/Packages/OathDatabase"), .package(path: "<SOURCE>/Packages/OathCloudBackup"), .package(path: "<SOURCE>/Packages/OathMarketData"), .package(path: "<SOURCE>/Packages/OathBitcoin"), .package(path: "<SOURCE>/Packages/OathWalletHandoff"), .package(path: "<SOURCE>/Packages/OathAezeed")
    ],
    targets: [.executableTarget(name: "WalletValidation", dependencies: [
        .product(name: "OathDatabase", package: "OathDatabase"),
        .product(name: "OathCloudBackup", package: "OathCloudBackup"),
        .product(name: "OathMarketData", package: "OathMarketData"),
        .product(name: "OathWalletHandoff", package: "OathWalletHandoff"),
        .product(name: "OathAezeed", package: "OathAezeed"),
        .product(name: "OathBitcoin", package: "OathBitcoin")
    ])], swiftLanguageModes: [.v6]
)
